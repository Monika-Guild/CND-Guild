import json
import boto3
import io
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import random
import math
import time
from sklearn.model_selection import RandomizedSearchCV, train_test_split
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error, mean_absolute_error
import datetime 
import operator
import pickle
from sklearn.externals import joblib
import seaborn as sns

def lambda_handler(event, context):
   
    print(event)
    #print(event['params']['querystring'].get('model_file_name'))
    print(event['model_file_name'])

    confirmed_cases = read_csv('time_series_covid19_confirmed_global.csv')
    cols = confirmed_cases.keys()
    confirmed = confirmed_cases.loc[:, cols[4]:cols[-1]]
    dates = confirmed.keys()
    future_forecast = np.array([i for i in range(len(dates) + 10)]).reshape(-1, 1)
    adjusted_dates = future_forecast[:-10]
    
    world_cases = []
    
    for i in dates:
        confirmed_sum = confirmed[i].sum()
        world_cases.append(confirmed_sum)

    world_cases = np.array(world_cases).reshape(-1, 1)
    
    svm_search = load_model(event['model_file_name'])
    svm_confirmed = svm_search.best_estimator_
    print(svm_confirmed)
    svm_pred = svm_confirmed.predict(future_forecast)
    
    start = '1/22/2020'
    start_date = datetime.datetime.strptime(start, '%m/%d/%Y')
    future_forecast_dates = []
    for i in range(len(future_forecast)):
        future_forecast_dates.append((start_date + datetime.timedelta(days=i)).strftime('%m/%d/%Y'))
    set(zip(future_forecast_dates[-10:], svm_pred[-10:]))
    generate_bar_chart(future_forecast_dates[-10:], np.array(svm_pred[-10:], dtype='int'))
    confirmedVsPredicted(adjusted_dates, world_cases, future_forecast, svm_pred)
    
def load_model(model_file_name):
    s3 = boto3.client("s3")
    file_obj = s3.get_object(Bucket='right-hous-capstone-s3', Key=model_file_name)
    return joblib.load(io.BytesIO(file_obj['Body'].read()))
    
def read_csv(object_key):
    s3 = boto3.client("s3")
    file_obj = s3.get_object(Bucket='right-hous-capstone-s3', Key=object_key)
    return pd.read_csv(io.BytesIO(file_obj['Body'].read()), encoding='utf-8')
    

def generate_bar_chart(labels, dates):
    sns.set()
    sns.set(rc = {'figure.figsize': (15, 5)})
    x = np.arange(len(labels))  # the label locations
    width = 0.5  # the width of the bars
    
    fig, ax = plt.subplots()
    rects1 = ax.bar(x - width/2, dates, width, label='Covid19 Forecast')
    #rects2 = ax.bar(x + width/2, women_means, width, label='Women')
    
    # Add some text for labels, title and custom x-axis tick labels, etc.
    ax.set_ylabel('Infections (10 millions')
    ax.set_title('Total global infections by date')
    ax.set_xticks(x)
    ax.set_xticklabels(labels)
    ax.legend()
    def autolabel(rects):
        for rect in rects:
            height = rect.get_height()
            ax.annotate('{}'.format(height),
                        xy=(rect.get_x() + rect.get_width() / 2, height),
                        xytext=(0, 3),  # 3 points vertical offset
                        textcoords="offset points",
                        ha='center', va='bottom')
    autolabel(rects1)
    fig.tight_layout()
    save_plot(plt, 'forecast_all.png')
    
def confirmedVsPredicted(adjusted_dates, world_cases, future_forecast, svm_pred):
    #Confirmed vs Predicted cases
    plt.figure(figsize=(20, 12))
    plt.plot(adjusted_dates, world_cases)
    plt.plot(future_forecast, svm_pred, linestyle='dashed', color='purple')
    plt.title('Number of Coronavirus cases over time', size = 30)
    plt.xlabel('Days since 1/22/2020', size=30)
    plt.ylabel('Number of Cases', size = 30)
    plt.legend(['Confirmed Cases', 'SVM Predictions'])
    plt.xticks(size=15)
    plt.yticks(size=15)
    save_plot(plt, 'actualVsForecasted.png')

def save_plot(plt, plt_name):
    img_data = io.BytesIO()
    plt.savefig(img_data, format='png')
    img_data.seek(0)
    bucket = boto3.resource('s3').Bucket('right-hous-capstone-s3')
    bucket.put_object(Body=img_data, ContentType='image/png', Key=plt_name)





