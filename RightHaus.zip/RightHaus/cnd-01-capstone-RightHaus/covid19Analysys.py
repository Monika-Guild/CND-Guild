import json
import boto3
import io
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import random
import math
import time
from sklearn.model_selection import RandomizedSearchCV, train_test_split
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error, mean_absolute_error
import datetime 
import operator
import pickle
from sklearn.externals import joblib

def lambda_handler(event, context):
    plt.style.use('seaborn')
    print("In lambda handler")
    confirmed_cases = read_csv('time_series_covid19_confirmed_global.csv')
    deaths_reported = read_csv('time_series_covid19_deaths_global.csv')
    recovered_cases = read_csv('time_series_covid19_recovered_global.csv')
    cols = confirmed_cases.keys()
    confirmed = confirmed_cases.loc[:, cols[4]:cols[-1]]
    deaths = deaths_reported.loc[:, cols[4]:cols[-1]]
    recoveries = recovered_cases.loc[:, cols[4]:cols[-1]]
    
    dates = confirmed.keys()
    world_cases = []
    total_deaths = []
    mortality_rate = []
    total_recovered = []
    
    for i in dates:
        confirmed_sum = confirmed[i].sum()
        death_sum = deaths[i].sum()
        recovered_sum = recoveries[i].sum()
        world_cases.append(confirmed_sum)
        total_deaths.append(death_sum)
        total_recovered.append(recovered_sum)
        mortality_rate.append(death_sum/confirmed_sum)
        
    #Convert all the dates and the cases into numpy array
    days_since_1_22 = np.array([i for i in range(len(dates))]).reshape(-1, 1)
    world_cases = np.array(world_cases).reshape(-1, 1)
    total_deaths = np.array(total_deaths).reshape(-1, 1)
    total_recovered = np.array(total_recovered).reshape(-1, 1)
        
    
    #Future forecasting for next 10 days
    days_in_future = 10
    future_forecast = np.array([i for i in range(len(dates) + days_in_future)]).reshape(-1, 1)
    adjusted_dates = future_forecast[:-10]
    
    #Convert all integers into datetime for better visualization
    start = '1/22/2020'
    start_date = datetime.datetime.strptime(start, '%m/%d/%Y')
    future_forecast_dates = []
    
    for i in range(len(future_forecast)):
        future_forecast_dates.append((start_date + datetime.timedelta(days=i)).strftime('%m/%d/%Y'))
        
    latest_confirmed = confirmed_cases[dates[-1]]
    latest_deaths = deaths_reported[dates[-1]]
    latest_recoveries = recovered_cases[dates[-1]]
    
    #Calculate the total number of confirmed cases for each country.
    unique_countries = list(confirmed_cases['Country/Region'].unique())
    country_confirmed_cases = []
    no_cases = []
    
    for i in unique_countries:
        cases = latest_confirmed[confirmed_cases['Country/Region'] == i].sum()
        
        if cases > 0:
            country_confirmed_cases.append(cases)
        else:
            no_cases.append(i)
            
    for i in no_cases:
        unique_countries.remove(i)
        
    unique_countries = [k for k, v in sorted(zip(unique_countries, country_confirmed_cases), key = operator.itemgetter(1), reverse = True)]
    
    for i in range(len(unique_countries)):
        country_confirmed_cases[i] = latest_confirmed[confirmed_cases['Country/Region'] == unique_countries[i]].sum()
        
    #Calculate the total number of confirmed cases for each state/province.
    unique_provinces = list(confirmed_cases['Province/State'].unique())
    province_confirmed_cases = []
    no_cases = []
    
    for i in unique_provinces:
        cases = latest_confirmed[confirmed_cases['Province/State'] == i].sum()
        if(cases > 0):
            province_confirmed_cases.append(cases)
        else:
           no_cases.append(i) 
        
    for i in no_cases:
        unique_provinces.remove(i)
    
    #Handling NaN values if there is any
    nan_indices = []
    
    for i in range(len(unique_provinces)):
        if type(unique_provinces[i]) == float:
            nan_indices.append(i)
            
    for i in nan_indices:
        unique_provinces.pop(i)
        province_confirmed_cases.pop(i)  
    #plot a bar graph to see total confirmed cases across diffeent countries
    plt.figure(figsize=(32,32))
    plt.barh(unique_countries, country_confirmed_cases)
    plt.title('Number of Covid19 confirmed cases in Countries')
    plt.xlabel('Number of covid19 confirmed cases')
    #plt.savefig('Top10BarGraph.png')
    save_plot(plt, 'TopAllBarGraph.png')
    
    #Plot only the top 10 countries with most confirmed cases
    visual_unique_countries = []
    visual_confirmed_cases = []
    others = np.sum(country_confirmed_cases[10:])
    
    for i in range(0, 10):
        visual_unique_countries.append(unique_countries[i])
        visual_confirmed_cases.append(country_confirmed_cases[i])
        
    visual_unique_countries.append('others')
    visual_confirmed_cases.append(others)
    plt.figure(figsize=(32,18))
    plt.barh(visual_unique_countries, visual_confirmed_cases)
    plt.title('Number of Covid19 confirmed cases in Countries/Regions')
    plt.xlabel('Number of covid19 confirmed cases')
    save_plot(plt, 'Top10BarGraph.png')
    
    c = random.choices(list(mcolors.CSS4_COLORS.values()), k = len(visual_unique_countries))
    plt.figure(figsize=(10,10))
    plt.title('Covid-19 confirmed cases per country')
    plt.pie(visual_confirmed_cases, colors=c)
    plt.legend(visual_unique_countries, loc='best')
    save_plot(plt, 'Top10PieChart.png')
    
    #Mortality rate of coronavirus over time
    mean_mortality_rate = np.mean(mortality_rate)
    plt.figure(figsize=(20, 12))
    plt.axhline(y=mean_mortality_rate, linestyle='--', color = 'black')
    plt.plot(adjusted_dates, mortality_rate, color='orange')
    plt.title('Mortality rate of Coronavirus cases over time', size = 30)
    plt.legend(['mortality rate', 'y=' + str(mean_mortality_rate)])
    plt.xlabel('Time', size=30)
    plt.ylabel('Mortality Rate', size = 30)
    plt.xticks(size=15)
    plt.yticks(size=15)
    save_plot(plt, 'MortalityRate.png')
    
    #Number of Coronavirus Cases recovered vs the number of deaths
    plt.figure(figsize=(20, 12))
    plt.plot(adjusted_dates, total_recovered, color='green')
    plt.plot(adjusted_dates, total_deaths, color='red')
    plt.legend(['recoveries', 'deaths'], loc = 'best', fontsize=20)
    #plt.plot(future_forecase, svm_pred, linestyle='dashed', color='purple')
    plt.title('Number of Coronavirus cases', size = 30)
    plt.xlabel('Time', size=30)
    plt.ylabel('Number of cases', size = 30)
    plt.xticks(size=15)
    plt.yticks(size=15)
    save_plot(plt, 'DeathsVsRecovery.png')
    
    
def read_csv(object_key):
    s3 = boto3.client("s3")
    file_obj = s3.get_object(Bucket='right-hous-capstone-s3', Key=object_key)
    return pd.read_csv(io.BytesIO(file_obj['Body'].read()), encoding='utf-8')
    
def save_plot(plt, plt_name):
    img_data = io.BytesIO()
    plt.savefig(img_data, format='png')
    img_data.seek(0)
    bucket = boto3.resource('s3').Bucket('right-hous-capstone-s3')
    bucket.put_object(Body=img_data, ContentType='image/png', Key=plt_name)
    
