# cnd-01-capstone-RightHaus
Capstone project - COVID19 - AI/ML
