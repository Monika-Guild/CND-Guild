import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import random
import math
import time
from sklearn.model_selection import RandomizedSearchCV, train_test_split
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error, mean_absolute_error
import datetime 
import operator
from sklearn.externals import joblib
plt.style.use('seaborn')
%matplotlib inline 



def main():  
    confirmed_cases = pd.read_csv('C:/Users/nandkkumar/Desktop/Nand/_1SelfStudy/MachineLearning/udemy/MLCourse/covid19/time_series_covid19_confirmed_global.csv')

    cols = confirmed_cases.keys()
    confirmed = confirmed_cases.loc[:, cols[4]:cols[-1]]


    dates = confirmed.keys()
    world_cases = []

    for i in dates:
        confirmed_sum = confirmed[i].sum()
        world_cases.append(confirmed_sum)


    #Convert all the dates and the cases into numpy array
    days_since_1_22 = np.array([i for i in range(len(dates))]).reshape(-1, 1)
    world_cases = np.array(world_cases).reshape(-1, 1)
    print('start generating models')
    #generate_svm_model(days_since_1_22, world_cases, 'all')
    print('starting for Brazil')
    generate_svm_model(days_since_1_22, country_sp_cases(confirmed_cases, 'Brazil', cols, dates), 'Brazil')
    generate_svm_model(days_since_1_22, country_sp_cases(confirmed_cases, 'Russia', cols, dates), 'Russia')
    generate_svm_model(days_since_1_22, country_sp_cases(confirmed_cases, 'India', cols, dates), 'India')
    generate_svm_model(days_since_1_22, country_sp_cases(confirmed_cases, 'United Kingdom', cols, dates), 'United_Kingdom')

def country_sp_cases(confirmed_cases, country, cols, dates):
    country_confirmed = confirmed_cases[confirmed_cases['Country/Region'].eq(country)].loc[:, cols[4]:cols[-1]]
    country_sp_cases = []
    for i in dates:
        confirmed_sum = country_confirmed[i].sum()
        country_sp_cases.append(confirmed_sum)
            
    country_sp_cases = np.array(country_sp_cases).reshape(-1, 1)
    return country_sp_cases
    
def generate_svm_model(days_since_1_22, cases, country):
    print('start for ' + country)
    kernel = ['poly', 'sigmoid', 'rbf']
    c = [0.01, 0.1, 1, 10]
    gamma = [0.01, 0.1, 1]
    epsilon = [0.01, 0.1, 1]
    shrinking = [True, False]
    svm_grid = {'kernel': kernel, 'C': c, 'gamma': gamma, 'epsilon': epsilon, 'shrinking': shrinking}

    svm = SVR()
    svm_search = RandomizedSearchCV(svm, svm_grid, scoring='neg_mean_squared_error', cv=3, return_train_score=True, n_jobs = 1, n_iter=40, verbose=1)
    X_train_confirmed, X_test_confirmed, Y_train_confirmed, Y_test_confirmed = train_test_split(days_since_1_22, cases, test_size=0.33, random_state=42)
    svm_search.fit(X_train_confirmed, Y_train_confirmed)
    file_name = 'svm_' + country
    joblib.dump(svm_search, file_name)
    
print('calling main function')
main()
