import json
import boto3
import sys
import logging
from boto3.dynamodb.conditions import Key

# retrieving the dynamodb client and object for 'user_health_record' table
dynamodb = boto3.resource('dynamodb', region_name='ap-south-1')
table = dynamodb.Table('patient_vitals_tbl')

def lambda_handler(event, context):
    # initializing the logger to print to 'stdout' with logging level 'INFO' 
    logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))
    logging.getLogger().setLevel(logging.INFO)
    
    # retrieving the input parameters from event for querying the data from table
    if 'patientId' in event:
        patientId = event['patientId']
        logging.info(f'input patientId: {patientId}')
    else:
        logging.error('expected patientId in the event but received None')
        raise TypeError('expected patientId in the event but received None')
    
    # beforeTimestamp is an optional field
    if 'beforeTimestamp' in event:
        beforeTimestamp = event['beforeTimestamp']
        logging.info(f'input beforeTimestamp: {beforeTimestamp}')
        
    # afterTimestamp is an optional field
    if 'afterTimestamp' in event:
        afterTimestamp = event['afterTimestamp']
        logging.info(f'input afterTimestamp: {afterTimestamp}')
    
    # querying the table with input parameters as conditions
    try:
        patientVitalsRecordList = []
        if 'beforeTimestamp' in event and 'afterTimestamp' not in event:
            response = table.query(KeyConditionExpression=Key('patient_id').eq(patientId) & Key('recorded_timestamp').lt(beforeTimestamp))
        elif 'afterTimestamp' in event and 'beforeTimestamp' not in event:
            response = table.query(KeyConditionExpression=Key('patient_id').eq(patientId) & Key('recorded_timestamp').gt(afterTimestamp))
        elif 'afterTimestamp' in event and 'beforeTimestamp' in event:
            response = table.query(KeyConditionExpression=Key('patient_id').eq(patientId) & Key('recorded_timestamp').between(afterTimestamp, beforeTimestamp))
        else:
            response = table.query(KeyConditionExpression=Key('patient_id').eq(patientId)) 
        
        # loop over the records from the response and build a list to be sent as return 
        for record in response[u'Items']:
            logging.info(f'record: {record}')
            patientVitalsRecord = PatientVitalsRecord(**record) 
            logging.info(f'patientVitalsRecord: {patientVitalsRecord.toJson()}')
            patientVitalsRecordList.append(patientVitalsRecord.toJson())
    except Exception as e:
        logging.error(e)
        raise e
    else:
        logging.info(patientVitalsRecordList)
        return {
            'statusCode': 200,
            'body': patientVitalsRecordList
        }

class PatientVitalsRecord:
    # for constructing the object with initial data
    def __init__(self, **kwargs):
        if 'patient_id' in kwargs:
            self.patientId = kwargs['patient_id']
        else:
            raise KeyError(f'expected patient_id but received None')
    
        if 'recorded_timestamp' in kwargs:
            self.recordedTimestamp = kwargs['recorded_timestamp']
        else:
            raise KeyError(f'expected recorded_timestamp but received None')
            
        if 'first_name' in kwargs:  
            self.firstName = kwargs['first_name']
        else:
            raise KeyError(f'expected first_name but received None')
            
        if 'last_name' in kwargs:  
            self.lastName = kwargs['last_name']
        else:
            raise KeyError(f'expected last_name but received None')
            
        if 'notification_email_id' in kwargs:
            self.notificationEmailId = kwargs['notification_email_id']
        else:
            raise KeyError(f'expected notification_email_id but received None')
            
        if 'current_room_no' in kwargs:  
            self.currentRoomNo = kwargs['current_room_no']
        else:
            raise KeyError(f'expected current_room_no but received None')
            
        if 'blood_pressure' in kwargs:
            self.bloodPressure = kwargs['blood_pressure']
        else:
            raise KeyError(f'expected blood_pressure but received None')
            
        if 'heart_rate' in kwargs:   
            self.heartRate = kwargs['heart_rate']
        else:
            raise KeyError(f'expected heart_rate but received None')
            
        if 'body_temperature' in kwargs:
            self.bodyTemperature = kwargs['body_temperature']
        else:
            raise KeyError(f'expected body_temperature but received None')
    
    def toJson(self):
        return json.loads(json.dumps(self, default=lambda o: o.__dict__))