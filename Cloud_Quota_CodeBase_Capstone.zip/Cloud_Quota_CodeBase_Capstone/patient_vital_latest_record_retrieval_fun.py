import json
import logging
import boto3
import sys

dynamodb = boto3.resource('dynamodb', region_name='ap-south-1')

def lambda_handler(event, context):
    # Initialize Logger to print the logs to stdout with INFO log level
    logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))
    logging.getLogger().setLevel(logging.INFO)
    
    # Look to see if the input paramters are present else raise an error
    if 'patientIdList' in event:
        patientIdList = event['patientIdList']
    else:
        logging.error('Expected patientIdList but received None')
        raise TypeError('Expected patientIdList but received None')
        
    
    try:
        patientVitalsRecordList = []
        if len(patientIdList) > 25:
            raise Exception(f'Request with patientIdList should not contain more than 25 items, but contains: {len(patientIdList)} items')
        for patientId in patientIdList:
            # Query paramteres to fetch records in descending order and limit to fetch only 1 record  
            params = {
                'KeyConditionExpression': 'patient_id = :patientId',
                'ExpressionAttributeValues': {
                    ':patientId': patientId
                },
                'Limit': 1,
                'ScanIndexForward': False
            }
            response = dynamodb.Table('patient_vitals_tbl').query(**params)
            if 'Items' in response and len(response['Items']) > 0:
                patientVitalsRecord = PatientVitalsRecord(**response[u'Items'][0]) 
                logging.info(f'patientVitalsRecord: {patientVitalsRecord.toJson()}')
                patientVitalsRecordList.append(patientVitalsRecord.toJson())
            else:
                logging.error(f'No record exists with patient_id : {patientId}')
    except Exception as e:
        logging.error(e)
        raise e
    else:    
        logging.info(patientVitalsRecordList)
        return {
            'statusCode': 200,
            'body': patientVitalsRecordList
        }
        
class PatientVitalsRecord:
    # for constructing the object with initial data
    def __init__(self, **kwargs):
        if 'patient_id' in kwargs:
            self.patientId = kwargs['patient_id']
        else:
            raise KeyError(f'expected patient_id but received None')
    
        if 'recorded_timestamp' in kwargs:
            self.recordedTimestamp = kwargs['recorded_timestamp']
        else:
            raise KeyError(f'expected recorded_timestamp but received None')
            
        if 'first_name' in kwargs:  
            self.firstName = kwargs['first_name']
        else:
            raise KeyError(f'expected first_name but received None')
            
        if 'last_name' in kwargs:  
            self.lastName = kwargs['last_name']
        else:
            raise KeyError(f'expected last_name but received None')
            
        if 'notification_email_id' in kwargs:
            self.notificationEmailId = kwargs['notification_email_id']
        else:
            raise KeyError(f'expected notification_email_id but received None')
            
        if 'current_room_no' in kwargs:  
            self.currentRoomNo = kwargs['current_room_no']
        else:
            raise KeyError(f'expected current_room_no but received None')
            
        if 'blood_pressure' in kwargs:
            self.bloodPressure = kwargs['blood_pressure']
        else:
            raise KeyError(f'expected blood_pressure but received None')
            
        if 'heart_rate' in kwargs:   
            self.heartRate = kwargs['heart_rate']
        else:
            raise KeyError(f'expected heart_rate but received None')
            
        if 'body_temperature' in kwargs:
            self.bodyTemperature = kwargs['body_temperature']
        else:
            raise KeyError(f'expected body_temperature but received None')
    
    def toJson(self):
        return json.loads(json.dumps(self, default=lambda o: o.__dict__))