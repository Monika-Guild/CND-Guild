import json
import boto3
import sys
import os
import logging

# retrieving the ses client
ses = boto3.client('ses', region_name="ap-south-1")

def lambda_handler(event, context):
    # initializing the logger to print to 'stdout' with logging level 'INFO'
    logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))
    logging.getLogger().setLevel(logging.INFO)
    
    # mining through the dynamodb event stream data to retrieve, analyse the patient vitals data to send an alert
    # if the health metrics are beyond the threshold limits(set through environment variables) 
    if event['Records']:
        records = event['Records']
        for record in records:
            if record['eventName'] == 'INSERT':
                logging.info(record)
                
                # we are interested only in the newly inserted records
                patientId = record['dynamodb']['NewImage']['patient_id']['S']
                firstName = record['dynamodb']['NewImage']['first_name']['S']
                emailAddress = record['dynamodb']['NewImage']['notification_email_id']['S']
                currentRoomNo = record['dynamodb']['NewImage']['current_room_no']['S']
                bloodPressure = record['dynamodb']['NewImage']['blood_pressure']['S']
                heartRate = record['dynamodb']['NewImage']['heart_rate']['S']
                bodyTemperature = record['dynamodb']['NewImage']['body_temperature']['S']
                
                if is_bp_critical(bloodPressure) or is_body_temp_critical(bodyTemperature) or is_heart_rate_critical(heartRate):
                    critical_vitals = []
                    if is_bp_critical(bloodPressure):
                        critical_vitals.append('blood pressure')
                    if is_body_temp_critical(bodyTemperature):
                        critical_vitals.append('body temperature')
                    if is_heart_rate_critical(heartRate):
                        critical_vitals.append('heart rate')
                        
                    crictical_metrics_str = (', ').join(critical_vitals)
                    
                    # building the alert mail body with data retrieved from the event stream
                    email_body = '''
                    Hi,
                    
                    {}'s {} is/are critically high at the moment.
                    
                    PATIENT ID -> {}
                    BLOOD PRESSURE -> {}
                    BODY TEMPERATURE -> {}
                    HEART RATE -> {}
                    CURRENT ROOM NO -> {} 
                    
                    Please alert the healthcare provider as soon as possible.
                    
                    Thanks,
                    Health Alert
                    '''.format(firstName, crictical_metrics_str, patientId, bloodPressure, bodyTemperature, heartRate, currentRoomNo)
                    
                    logging.info(email_body)
                    
                    # using AWS SES to send the mail to the registered user mailid's
                    try:
                        response = ses.send_email(
                            Destination={
                                'ToAddresses': [
                                    emailAddress
                                    ]
                            },
                            Message={
                                'Subject': {
                                    'Charset': 'UTF-8',
                                    'Data': 'Health Status Alert !!'
                                },
                                'Body': {
                                    'Text': {
                                        'Charset': 'UTF-8',
                                        'Data': email_body
                                    }
                                } 
                            },
                            Source='chandrasanthosh4@gmail.com'
                            )
                    except Exception as e:
                        logging.error(f'e')
                        raise e
                    else:
                        logging.info(f'Email alert is sent to {firstName}: {response}')
                        return {
                            'statusCode': 200,
                            'body': json.dumps(f'Email alert is sent to {firstName}: {response}')
                        }
                else:
                    logging.info(f'{firstName} health metrics are under limits')
                    return {
                        'statusCode': 200,
                        'body': json.dumps(f'{firstName} health metrics are under limits')
                    }
            else:
                return {
                    'statusCode': 200
                }
    else:
        return {
            'statusCode': 200
        }

def is_bp_critical(inp_bp):
    ref_bp = os.environ['BLOOD_PRESSURE']
    (sys_inp_bp, dia_inp_bp) = inp_bp.split('/')
    (sys_ref_bp, dia_ref_bp) = ref_bp.split('/')
    return int(sys_inp_bp) > int(sys_ref_bp) or int(dia_inp_bp) > int(dia_ref_bp)
    
def is_body_temp_critical(body_temperature):
    return float(body_temperature) > float(os.environ['BODY_TEMPERATURE'])
    
def is_heart_rate_critical(heart_rate):
    return float(heart_rate) > float(os.environ['HEART_RATE'])