import json
import boto3
import sys
import logging

# retrieving dynamodb client and object for 'user_health record' table
dynamodb = boto3.resource('dynamodb', region_name='ap-south-1')
table = dynamodb.Table('patient_vitals_tbl')
    
def lambda_handler(event, context):
    # initializing logger to print to 'stdout' with logging level 'INFO'
    logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))
    logging.getLogger().setLevel(logging.INFO)
    
    # passing the event object to construct the userHealthRecord object 
    if 'patient_vitals_data' in event :
        try:
            # retrieving input from the event
            patient_vitals_data = event['patient_vitals_data']
            logging.info(f'type: {type(patient_vitals_data)}')
            patientVitalsRecord = PatientVitalsRecord(**patient_vitals_data)
            logging.info(f'patientVitalsRecord: {patientVitalsRecord}')
        except KeyError as ke:
            logging.error(ke) 
            raise ke
    else:
        logging.error(f'expected patient vitals data but received None')
        raise TypeError(f'expected patient vitals data but received None')
    
    # saving the patientVitalsRecord object data to dynamodb table
    try:
        table.put_item(
            Item={
                'patient_id':patientVitalsRecord.patientId(),
                'recorded_timestamp':patientVitalsRecord.recordedTimestamp(),
                'first_name':patientVitalsRecord.firstName(),
                'last_name':patientVitalsRecord.lastName(),
                'notification_email_id':patientVitalsRecord.notificationEmailId(),
                'current_room_no':patientVitalsRecord.currentRoomNo(),
                'blood_pressure':patientVitalsRecord.bloodPressure(),
                'heart_rate':patientVitalsRecord.heartRate(),
                'body_temperature':patientVitalsRecord.bodyTemperature()
            }
        )
    except Exception as e:
        logging.error(e)
        raise e
    else:
        logging.info(f'Patient vitals record saved successfully with id: {patientVitalsRecord.patientId()} !!')
        return {
            'statusCode': 200,
            'body': json.dumps(f'Patient vitals record saved successfully with id: {patientVitalsRecord.patientId()} !!')
        }

class PatientVitalsRecord:
    # for constructing the object with initial data
    def __init__(self, **kwargs):
        if 'patientId' in kwargs:
            self._patientId = kwargs['patientId']
        else:
            raise KeyError(f'expected patientId but received None')
    
        if 'recordedTimestamp' in kwargs:
            self._recordedTimestamp = kwargs['recordedTimestamp']
        else:
            raise KeyError(f'expected recordedTimestamp but received None')
            
        if 'firstName' in kwargs:  
            self._firstName = kwargs['firstName']
        else:
            raise KeyError(f'expected firstName but received None')
            
        if 'lastName' in kwargs:  
            self._lastName = kwargs['lastName']
        else:
            raise KeyError(f'expected firstName but received None')
            
        if 'notificationEmailId' in kwargs:
            self._notificationEmailId = kwargs['notificationEmailId']
        else:
            raise KeyError(f'expected notificationEmailId but received None')
            
        if 'currentRoomNo' in kwargs:  
            self._currentRoomNo = kwargs['currentRoomNo']
        else:
            raise KeyError(f'expected currentRoomNo but received None')
            
        if 'bloodPressure' in kwargs:
            self._bloodPressure = kwargs['bloodPressure']
        else:
            raise KeyError(f'expected bloodPressure but received None')
            
        if 'heartRate' in kwargs:   
            self._heartRate = kwargs['heartRate']
        else:
            raise KeyError(f'expected heartRate but received None')
            
        if 'bodyTemperature' in kwargs:
            self._bodyTemperature = kwargs['bodyTemperature']
        else:
            raise KeyError(f'expected bodyTemperature but received None')
    
    # public getter methods for all the private variables        
    def patientId(self):
        return self._patientId
    
    def recordedTimestamp(self):
        return self._recordedTimestamp
        
    def firstName(self):
        return self._firstName
        
    def lastName(self):
        return self._lastName
    
    def notificationEmailId(self):
        return self._notificationEmailId
        
    def currentRoomNo(self):
        return self._currentRoomNo
        
    def bloodPressure(self):
        return self._bloodPressure
        
    def heartRate(self):
        return self._heartRate
        
    def bodyTemperature(self):
        return self._bodyTemperature