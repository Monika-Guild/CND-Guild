package in.hp.boot.userdetailsservice.repository;

import in.hp.boot.userdetailsservice.entity.InterviewMapping;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface InterviewMappingRepository extends JpaRepository<InterviewMapping, Integer> {

    @Query(value = "select r from InterviewMapping r where r.candidateEmailId = :emailId and r.interviewLevel = :level")
    Optional<InterviewMapping> findRowByEmailIdAndLevel(String emailId, String level);
}
