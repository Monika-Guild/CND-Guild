package in.hp.boot.userdetailsservice.service;

import in.hp.boot.userdetailsservice.dto.LambdaDto;
import in.hp.boot.userdetailsservice.entity.Candidate;
import in.hp.boot.userdetailsservice.entity.InterviewMapping;
import in.hp.boot.userdetailsservice.entity.Panelist;
import in.hp.boot.userdetailsservice.repository.InterviewMappingRepository;
import in.hp.boot.userdetailsservice.repository.PanelistRepository;
import in.hp.boot.userdetailsservice.utils.AppConstants;
import in.hp.boot.userdetailsservice.utils.CommonUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Slf4j
public class MappingService {

    @Value("${interview-mapping.email-flag.level-one: true}")
    private Boolean levelOneEmailFlag;

    @Value("${interview-mapping.email-flag.level-two: true}")
    private Boolean levelTwoEmailFlag;

    @Value("${interview-mapping.timeslot-delay.first: 5}")
    private long firstCandidateDelayTime;

    @Value("${interview-mapping.timeslot-delay.subsequent: 15}")
    private long subsequentDelayTime;

    @Autowired
    private PanelistRepository panelistRepository;

    @Autowired
    private InterviewMappingRepository interviewMappingRepository;

    @Autowired
    private LambdaService lambdaService;

    public void mapCandidateLevelOne(Candidate candidate) {
        List<Panelist> panelists = panelistRepository
                .fetchPanelistsForLevelOne(Sort.by(Sort.Direction.ASC, "checkInTime"));

        panelists.sort(Comparator
                .comparingInt((Panelist p) -> p.getCandidatesLevelOne().size())
                .thenComparing(Panelist::getCheckInTime));

        Panelist panelist = panelists.get(0);
        candidate.setPanelistLevelOne(panelist);
        candidate.setAllocateLevelOne(true);
        panelist.getCandidatesLevelOne().add(candidate);
        panelistRepository.saveAndFlush(panelist);

        // TODO: insert interview_mapping table row
        InterviewMapping interviewMapping = InterviewMapping.builder()
                .setBasicDetails(panelist, candidate)
                .setEmailFlag(levelOneEmailFlag)
                .setInterviewLevel(AppConstants.LEVEL_ONE)
                .setTimeSlot(getTimeSlotValue(panelist, panelist.getCandidatesLevelOne()))
                .build();
        interviewMappingRepository.saveAndFlush(interviewMapping);

        sendNotification(panelist.getEmailId(), "panelist",
                buildEmailMessage(candidate.getName(), candidate.getEmailId(), interviewMapping.getTimeSlot()));
        sendNotification(candidate.getEmailId(), "candidate",
                buildEmailMessage(panelist.getName(), panelist.getEmailId(), interviewMapping.getTimeSlot()));
    }

    public void mapCandidateLevelTwo(Candidate candidate) {
        List<Panelist> panelists = panelistRepository
                .fetchPanelistsForLevelTwo(Sort.by(Sort.Direction.ASC, "checkInTime"));

        Panelist panelist = panelists.stream().filter(p -> !p.getIsTalent())
                .sorted(Comparator
                        .comparingInt((Panelist p) -> p.getCandidatesLevelTwo().size())
                        .thenComparing(Panelist::getCheckInTime))
                .collect(Collectors.toList()).get(0);

//        Panelist panelist = panelists.get(0);
        candidate.setPanelistLevelTwo(panelist);
        candidate.setAllocatedLevelTwo(true);
        panelist.getCandidatesLevelTwo().add(candidate);
        panelistRepository.saveAndFlush(panelist);

        InterviewMapping interviewMapping = InterviewMapping.builder()
                .setBasicDetails(panelist, candidate)
                .setEmailFlag(levelTwoEmailFlag)
                .setInterviewLevel(AppConstants.LEVEL_TWO)
                .setTimeSlot(getTimeSlotValue(panelist, panelist.getCandidatesLevelTwo()))
                .build();
        interviewMappingRepository.saveAndFlush(interviewMapping);

        sendNotification(panelist.getEmailId(), "panelist",
                buildEmailMessage(candidate.getName(), candidate.getEmailId(), interviewMapping.getTimeSlot()));
        sendNotification(candidate.getEmailId(), "candidate",
                buildEmailMessage(panelist.getName(), panelist.getEmailId(), interviewMapping.getTimeSlot()));
    }

    private Timestamp getTimeSlotValue(Panelist panelist, List<Candidate> candidates) {
        LocalDateTime timeSlot = null;
        if (candidates.size() == 1) {
            timeSlot = LocalDateTime.now().plusMinutes(firstCandidateDelayTime);
        } else {
            String lastCandidateEmailId = candidates.get(candidates.size() - 2).getEmailId();
            Optional<InterviewMapping> row = interviewMappingRepository.findRowByEmailIdAndLevel(
                    lastCandidateEmailId, panelist.getCurrentLevel());
            if (row.isPresent()) {
                timeSlot = row.get().getTimeSlot().toLocalDateTime().plusMinutes(subsequentDelayTime);
            }
        }
        return timeSlot != null ? Timestamp.valueOf(timeSlot) : null;
    }

    private String buildEmailMessage(String name, String emailId, Timestamp timestamp) {
        return "Your interview is scheduled with "
                + name + " (" + emailId + ")"
                + " on " + CommonUtils.getDate(timestamp)
                + " at " + CommonUtils.getHourAndMinute(timestamp);
    }

    private void sendNotification(String email, String type, String message) {
        LambdaDto lambdaDto = new LambdaDto();
        lambdaDto.setType(type);
        lambdaDto.setEmail(email);
        lambdaDto.setMessage(message);
        lambdaService.sendNotification(lambdaDto);
    }
}
