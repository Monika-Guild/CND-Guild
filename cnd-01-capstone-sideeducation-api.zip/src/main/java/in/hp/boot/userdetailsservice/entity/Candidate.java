package in.hp.boot.userdetailsservice.entity;

import lombok.Data;

import javax.persistence.*;
import java.sql.Date;
import java.sql.Timestamp;

@Data
@Entity
@Table(name = "CANDIDATE_DETAILS")
public class Candidate {

    @Id
    @GeneratedValue
    private Integer id;

    private String name;

    @Column(name = "email_id")
    private String emailId;

    @Column(name = "contact_number")
    private Long contactNumber;

    @Column(name = "github_link")
    private String githubLink;

    @Column(name = "linkedin_link")
    private String linkedInLink;

    @Column(name = "resume_s3_link")
    private String resumeS3Link;

    @Column(name = "primary_skill_one")
    private String primarySkillOne;

    @Column(name = "primary_skill_two")
    private String primarySkillTwo;

    @Column(name = "primary_skill_three")
    private String primarySkillThree;

    @Column(name = "date_of_blitz")
    private Date dateOfBlitz;

    @Column(name = "is_checked_in")
    private Boolean isCheckedIn;

    @Column(name = "check_in_time")
    private Timestamp checkInTime;

    @Column(name = "allocated_flag_level_one")
    private Boolean allocateLevelOne;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "panelistLevelOneId")
    private Panelist panelistLevelOne;

    @Column(name = "feedback_level_one")
    private String feedbackLevelOne;

    @Column(name = "cleared_level_one")
    private Boolean clearedLevelOne;

    @Column(name = "allocated_flag_level_two")
    private Boolean allocatedLevelTwo;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "panelistLevelTwoId")
    private Panelist panelistLevelTwo;

    @Column(name = "feedback_level_two")
    private String feedbackLevelTwo;

    @Column(name = "cleared_level_two")
    private Boolean clearedLevelTwo;

    @Column(name = "is_selected")
    private Boolean isSelected;

    @Column(name = "interview_completed")
    private Boolean interviewCompleted;

    @Override
    public String toString() {
        return "Candidate{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", emailId='" + emailId + '\'' +
                ", contactNumber=" + contactNumber +
                ", githubLink='" + githubLink + '\'' +
                ", linkedInLink='" + linkedInLink + '\'' +
                ", resumeS3Link='" + resumeS3Link + '\'' +
                ", primarySkillOne='" + primarySkillOne + '\'' +
                ", primarySkillTwo='" + primarySkillTwo + '\'' +
                ", primarySkillThree='" + primarySkillThree + '\'' +
                ", dateOfBlitz=" + dateOfBlitz +
                ", isCheckedIn=" + isCheckedIn +
                ", checkInTime=" + checkInTime +
                ", allocateLevelOne=" + allocateLevelOne +
                ", feedbackLevelOne='" + feedbackLevelOne + '\'' +
                ", clearedLevelOne=" + clearedLevelOne +
                ", allocatedLevelTwo=" + allocatedLevelTwo +
                ", feedbackLevelTwo='" + feedbackLevelTwo + '\'' +
                ", clearedLevelTwo=" + clearedLevelTwo +
                ", isSelected=" + isSelected +
                ", interviewCompleted=" + interviewCompleted +
                '}';
    }
}
