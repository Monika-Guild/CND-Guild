package in.hp.boot.userdetailsservice.utils;

import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Optional;

public class CommonUtils {

    public static LocalDate convertDateToLocalDate(Date date) {
        return Optional.ofNullable(date)
                .map(Date::toLocalDate)
                .orElse(null);
    }

    public static Date convertLocalDateToDate(LocalDate localDate) {
        return Optional.ofNullable(localDate).map(Date::valueOf).orElse(null);
    }

    public static LocalDateTime convertTimestampToLocalDateTime(Timestamp timestamp) {
        return Optional.ofNullable(timestamp)
                .map(Timestamp::toLocalDateTime)
                .orElse(null);
    }

    public static Timestamp convertLocalDateTimeToTimestamp(LocalDateTime localDateTime) {
        return Optional.ofNullable(localDateTime).map(Timestamp::valueOf).orElse(null);
    }

    public static String getDate(Timestamp timestamp) {
        return timestamp.toLocalDateTime().toLocalDate().toString();
    }

    public static String getHourAndMinute(Timestamp timestamp) {
        LocalTime localTime = timestamp.toLocalDateTime().toLocalTime();
        return localTime.getHour() + ":" + localTime.getMinute();
    }
}
