package in.hp.boot.userdetailsservice.service;

import in.hp.boot.userdetailsservice.dto.CandidateDto;
import in.hp.boot.userdetailsservice.dto.LambdaDto;
import in.hp.boot.userdetailsservice.entity.Candidate;
import in.hp.boot.userdetailsservice.mapper.CandidateMapper;
import in.hp.boot.userdetailsservice.repository.CandidateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CandidateService {

    @Autowired
    private CandidateRepository candidateRepository;

    @Autowired
    private MappingService mappingService;

    @Autowired
    private CandidateMapper candidateMapper;

    @Autowired
    private LambdaService lambdaService;

    public List<CandidateDto> getAllCandidates() {
        List<Candidate> candidates = candidateRepository.findAll();
        List<CandidateDto> candidateDtos = new ArrayList<>();
        if (!candidates.isEmpty()) {
            candidateDtos = candidates.stream()
                    .map(candidateMapper::toDto)
                    .collect(Collectors.toList());
        }
        return candidateDtos;
    }

    public CandidateDto getCandidate(String email) {
        Optional<Candidate> candidateOptional = candidateRepository.findByEmailId(email);
        return candidateOptional.map(candidate -> candidateMapper.toDto(candidate)).orElse(null);
    }

    public boolean addCandidate(CandidateDto candidateDto) {
        if (candidateRepository.findByEmailId(candidateDto.getEmailId()).isPresent())
            return false;
        candidateDto.setIsCheckedIn(false);
        candidateDto.setCheckInTime(null);
        candidateRepository.save(candidateMapper.toEntity(candidateDto));
        return true;
    }

    public void updateCandidate(CandidateDto candidateDto) {
        updateCandidate(candidateMapper.toEntity(candidateDto));
    }

    public void updateCandidate(Candidate candidate) {
        candidateRepository.save(candidate);
    }

    public boolean deleteCanidate(String email) {
        return candidateRepository.deleteByEmailId(email) > 0;
    }

    @Transactional
    public boolean checkIn(String email) {
        Optional<Candidate> optional = candidateRepository.findByEmailId(email);
        if (!optional.isPresent() || optional.get().getIsCheckedIn()) {
            return false;
        } else {
            LambdaDto lambdaDto = new LambdaDto();
            lambdaDto.setEmail(email);
            lambdaDto.setType("candidate");
            lambdaService.subscribe(lambdaDto);

            Candidate candidate = optional.get();
            candidate.setIsCheckedIn(true);
            candidate.setCheckInTime(new Timestamp(System.currentTimeMillis()));
            mappingService.mapCandidateLevelOne(candidate);
        }
        return true;
    }

    @Transactional
    public void mapCandidateLevelTwo(CandidateDto candidateDto) {
        Candidate candidate = candidateRepository.findByEmailId(candidateDto.getEmailId()).get();
        candidate.setFeedbackLevelOne(candidateDto.getFeedbackLevelOne());
        candidate.setClearedLevelOne(candidateDto.getIsLevelOneCleared());
        mappingService.mapCandidateLevelTwo(candidate);
    }

    @Transactional
    public void clearCandidate(CandidateDto candidateDto) {
        Candidate candidate = candidateRepository.findByEmailId(candidateDto.getEmailId()).get();
        candidate.setFeedbackLevelTwo(candidateDto.getFeedbackLevelTwo());
        candidate.setClearedLevelTwo(candidateDto.getIsLevelTwoCleared());
        candidate.setIsSelected(candidateDto.getIsSelected());
        candidate.setInterviewCompleted(true);
        candidateRepository.save(candidate);
    }
}
