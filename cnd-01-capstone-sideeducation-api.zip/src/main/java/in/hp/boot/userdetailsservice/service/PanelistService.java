package in.hp.boot.userdetailsservice.service;

import in.hp.boot.userdetailsservice.dto.CandidateDto;
import in.hp.boot.userdetailsservice.dto.LambdaDto;
import in.hp.boot.userdetailsservice.dto.PanelistDto;
import in.hp.boot.userdetailsservice.entity.Panelist;
import in.hp.boot.userdetailsservice.mapper.PanelistMapper;
import in.hp.boot.userdetailsservice.repository.PanelistRepository;
import in.hp.boot.userdetailsservice.utils.AppConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class PanelistService {

    @Autowired
    PanelistRepository panelistRepository;

    @Autowired
    private PanelistMapper panelistMapper;

    @Autowired
    private CandidateService candidateService;

    @Autowired
    private LambdaService lambdaService;

    public List<PanelistDto> getAllPanelists() {
        List<Panelist> panelists = panelistRepository.findAll();
        List<PanelistDto> panelistsDto = new ArrayList<>();

        if (!panelists.isEmpty()) {
            panelistsDto = panelists.stream()
                    .map(panelistMapper::toDto)
                    .collect(Collectors.toList());
        }
        return panelistsDto;
    }

    public PanelistDto getPanelist(String email) {
        Optional<Panelist> optional = panelistRepository.findByEmailId(email);
        return optional.map(panelist -> {
            panelist.getCandidatesLevelOne();
            panelist.getCandidatesLevelTwo();
            return panelistMapper.toDto(panelist);
        }).orElse(null);
    }

    /**
     * TODO: handle exceptions later, for now returning boolean to check if data persisted
     *
     * @param panelistDto
     * @return
     */
    public boolean addPanelist(PanelistDto panelistDto) {
        if (panelistRepository.findByEmailId(panelistDto.getEmailId()).isPresent())
            return false;
        // setting default values, when panelist is created he will not be checked in
        panelistDto.setIsCheckedIn(false);
        panelistDto.setCheckInTime(null);
        panelistDto.setIsTalent(Optional.ofNullable(panelistDto.getIsTalent()).orElse(false));
        Panelist panelist = panelistMapper.toEntity(panelistDto);
        panelistRepository.save(panelist);
        return true;
    }

    @Transactional
    public boolean deletePanelist(String email) {
        return panelistRepository.deleteByEmailId(email) > 0;
    }

    public boolean checkIn(String email) {
        Optional<Panelist> optional = panelistRepository.findByEmailId(email);
        if (!optional.isPresent() || optional.get().getIsCheckedIn().booleanValue()) {
            return false;
        } else {
            Panelist panelist = optional.get();
            panelist.setIsCheckedIn(true);
            panelist.setCheckInTime(new Timestamp(System.currentTimeMillis()));
            panelist.setIsAvailable(true);
            // TODO: Check if this field will be present at data insertion time
            // panelist.setCurrentLevel(AppConstants.LEVEL_ONE);
            panelistRepository.save(panelist);

            LambdaDto lambdaDto = new LambdaDto();
            lambdaDto.setEmail(panelist.getEmailId());
            lambdaDto.setType("panelist");
            lambdaService.subscribe(lambdaDto);
            return true;
        }
    }

    public boolean clearCandidate(String email, CandidateDto candidateDto) {
        try {
            Panelist panelist = panelistRepository.findByEmailId(email).get();
            String level = panelist.getCurrentLevel();

            if (level.equals(AppConstants.LEVEL_ONE) && candidateDto.getIsLevelOneCleared()) {
                candidateService.mapCandidateLevelTwo(candidateDto);
            } else {
                candidateDto.setIsSelected(level.equals(AppConstants.LEVEL_TWO)
                        && candidateDto.getIsLevelTwoCleared());
                candidateService.clearCandidate(candidateDto);
            }
            return true;
        } catch (Exception ex) {
            // TODO: log
            return false;
        }
    }
}
