package in.hp.boot.userdetailsservice.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
@ApiModel("Panelist")
public class PanelistDto {

    private String name;
    private String emailId;
    private Long contactNumber;
    private List<String> primarySkills;

    private LocalDate dateOfBlitz;
    private Boolean isCheckedIn;
    private LocalDateTime checkInTime;

    private Boolean isAvailable;
    private LocalDateTime availableStartTime;
    private LocalDateTime availableEndTime;
    private String currentLevel;
    private Boolean isTalent;

    private List<CandidateDto> candidates;
}
