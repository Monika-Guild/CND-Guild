package in.hp.boot.userdetailsservice.controller;

import in.hp.boot.userdetailsservice.dto.CandidateDto;
import in.hp.boot.userdetailsservice.service.CandidateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("/candidates")
public class CandidateController {

    @Autowired
    private CandidateService candidateService;

    @GetMapping
    public List<CandidateDto> getAllCandidates() {
        return candidateService.getAllCandidates();
    }

    @GetMapping("/{email}")
    public ResponseEntity<CandidateDto> getCandidateByEmail(@PathVariable String email) {
        CandidateDto candidate = candidateService.getCandidate(email);
        return Objects.nonNull(candidate) ? ResponseEntity.ok(candidate) : ResponseEntity.badRequest().build();
    }

    @PostMapping
    public ResponseEntity<Object> addCandidate(@RequestBody CandidateDto candidateDto) {
        boolean isPersisted = candidateService.addCandidate(candidateDto);
        HttpStatus status = isPersisted ? HttpStatus.OK : HttpStatus.BAD_REQUEST;
        return ResponseEntity.status(status).build();
    }

    @DeleteMapping("/{email}")
    public ResponseEntity<Object> deleteCandidate(@PathVariable String email) {
        return candidateService.deleteCanidate(email) ? ResponseEntity.ok().build()
                : ResponseEntity.badRequest().build();
    }


    @PostMapping("/checkIn/{email}")
    public ResponseEntity<Object> checkIn(@PathVariable String email) {
        return candidateService.checkIn(email) ? ResponseEntity.ok().build()
                : ResponseEntity.badRequest().build();
    }
}
