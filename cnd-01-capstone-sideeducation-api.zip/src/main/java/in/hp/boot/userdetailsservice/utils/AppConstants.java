package in.hp.boot.userdetailsservice.utils;

public class AppConstants {
    public static final String LEVEL_ONE = "ONE";
    public static final String LEVEL_TWO = "TWO";
}
