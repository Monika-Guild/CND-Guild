package in.hp.boot.userdetailsservice.service;

import in.hp.boot.userdetailsservice.dto.LambdaDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

/**
 * TODO: refactor the methods later
 */
@Slf4j
@Service
public class LambdaService {

    @Value("${email.gateway.subscription}")
    private String subscriptionUrl;

    @Value("${email.gateway.notification}")
    private String notifyUrl;

    @Value("${email.send-email: false}")
    private boolean sendEmail;

    public void subscribe(LambdaDto lambdaDto) {
        if (sendEmail) {
            log.info("Sending subscription request [{}]", lambdaDto);
            try {
                sendEmail(lambdaDto, subscriptionUrl);
            } catch (Exception e) {
                log.error("Error in subscription [{}]", e.getMessage());
            }
        } else {
            log.info("Email Flag: {}, Emails will not be triggered.", sendEmail);
        }
    }

    public void sendNotification(LambdaDto lambdaDto) {
        if (sendEmail) {
            log.info("Sending Notification request [{}]", lambdaDto);
            try {
                sendEmail(lambdaDto, notifyUrl);
            } catch (Exception e) {
                log.error("Error in notifying [{}]", e.getMessage());
            }
        } else {
            log.info("Email Flag: {}, Emails will not be triggered.", sendEmail);
        }
    }

    private void sendEmail(LambdaDto lambdaDto, String url) {
        HttpHeaders headers = new HttpHeaders();
        headers.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);

        RestTemplate restTemplate = new RestTemplate();
        HttpEntity<LambdaDto> entity = new HttpEntity<>(lambdaDto, headers);
        log.info("Request [{}]", entity);
        ResponseEntity<String> response = restTemplate.postForEntity(url, entity, String.class);
        log.info("Response [{}]", response.getStatusCodeValue());
    }
}
