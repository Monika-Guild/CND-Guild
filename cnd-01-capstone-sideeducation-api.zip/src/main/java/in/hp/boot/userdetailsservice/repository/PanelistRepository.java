package in.hp.boot.userdetailsservice.repository;

import in.hp.boot.userdetailsservice.entity.Panelist;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface PanelistRepository extends JpaRepository<Panelist, Integer> {

    Optional<Panelist> findByEmailId(String emailId);

    Integer deleteByEmailId(String email);

    /* TODO: Use update query when needed, rn using find and save again
    @Query("update Panelist p set p.isCheckedIn = true, p.checkInTime = :timestamp where p.email = :email")
    void updateCheckIn(@Param("email") String email, @Param("timestamp") Timestamp timestamp);
    */

    @Query(value = "select p from Panelist p where p.isAvailable = TRUE and p.currentLevel = 'ONE'")
    List<Panelist> fetchPanelistsForLevelOne(Sort sort);

    @Query(value = "select p from Panelist p where p.isAvailable = TRUE and p.currentLevel = 'TWO'")
    List<Panelist> fetchPanelistsForLevelTwo(Sort sort);
}
