package in.hp.boot.userdetailsservice.entity;

import lombok.Data;

import javax.persistence.*;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

@Data
@Entity
@Table(name = "PANELIST_DETAILS")
public class Panelist {

    @Id
    @GeneratedValue
    private Integer id;

    private String name;

    @Column(name = "email_id")
    private String emailId;

    @Column(name = "contact_number")
    private Long contactNumber;

    @Column(name = "primary_skill_one")
    private String primarySkillOne;

    @Column(name = "primary_skill_two")
    private String primarySkillTwo;

    @Column(name = "primary_skill_three")
    private String primarySkillThree;

    @Column(name = "date_of_blitz")
    private Date dateOfBlitz;

    @Column(name = "is_checked_in")
    private Boolean isCheckedIn;

    @Column(name = "check_in_time")
    private Timestamp checkInTime;

    @Column(name = "available_flag")
    private Boolean isAvailable;

    @Column(name = "available_start_time")
    private Timestamp availableStartTime;

    @Column(name = "available_end_time")
    private Timestamp availableEndTime;

    @Column(name = "current_level")
    private String currentLevel;

    @Column(name = "is_talent")
    private Boolean isTalent;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "panelistLevelOne", fetch = FetchType.LAZY)
    private List<Candidate> candidatesLevelOne;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "panelistLevelTwo", fetch = FetchType.LAZY)
    private List<Candidate> candidatesLevelTwo;

    @Override
    public String toString() {
        return "Panelist{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", emailId='" + emailId + '\'' +
                ", contactNumber=" + contactNumber +
                ", primarySkillOne='" + primarySkillOne + '\'' +
                ", primarySkillTwo='" + primarySkillTwo + '\'' +
                ", primarySkillThree='" + primarySkillThree + '\'' +
                ", dateOfBlitz=" + dateOfBlitz +
                ", isCheckedIn=" + isCheckedIn +
                ", checkInTime=" + checkInTime +
                ", isAvailable=" + isAvailable +
                ", availableStartTime=" + availableStartTime +
                ", availableEndTime=" + availableEndTime +
                ", currentLevel='" + currentLevel + '\'' +
                ", isTalent='" + isTalent + '\'' +
                '}';
    }
}
