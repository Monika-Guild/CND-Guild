package in.hp.boot.userdetailsservice.mapper;

import in.hp.boot.userdetailsservice.dto.CandidateDto;
import in.hp.boot.userdetailsservice.entity.Candidate;
import in.hp.boot.userdetailsservice.utils.CommonUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Iterator;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Component
public class CandidateMapper {

    @Autowired
    private PanelistMapper panelistMapper;

    public CandidateDto toDto(Candidate candidate) {
        CandidateDto candidateDto = new CandidateDto();

        candidateDto.setName(candidate.getName());
        candidateDto.setEmailId(candidate.getEmailId());
        candidateDto.setContactNumber(candidate.getContactNumber());
        candidateDto.setGithubLink(candidate.getGithubLink());
        candidateDto.setLinkedInLink(candidate.getLinkedInLink());
        candidateDto.setResumeS3Link(candidate.getResumeS3Link());

        candidateDto.setIsLevelOneAllocated(candidate.getAllocateLevelOne());
        candidateDto.setFeedbackLevelOne(candidate.getFeedbackLevelOne());
        candidateDto.setIsLevelOneCleared(candidate.getClearedLevelOne());
//        Optional.ofNullable(candidate.getPanelistLevelOne())
//                .ifPresent(panelist -> candidateDto.setPanelistLevelOne(panelistMapper.toDto(panelist)));

        candidateDto.setIsLevelTwoAllocated(candidate.getAllocatedLevelTwo());
        candidateDto.setFeedbackLevelTwo(candidate.getFeedbackLevelTwo());
        candidateDto.setIsLevelTwoCleared(candidate.getClearedLevelTwo());
//        Optional.ofNullable(candidate.getPanelistLevelTwo())
//                .ifPresent(panelist -> candidateDto.setPanelistLevelTwo(panelistMapper.toDto(panelist)));

        candidateDto.setPrimarySkills(Stream.of(
                candidate.getPrimarySkillOne(),
                candidate.getPrimarySkillTwo(),
                candidate.getPrimarySkillThree())
                .collect(Collectors.toList()));

        candidateDto.setDateOfBlitz(CommonUtils.convertDateToLocalDate(candidate.getDateOfBlitz()));
        candidateDto.setIsCheckedIn(candidate.getIsCheckedIn());
        candidateDto.setCheckInTime(CommonUtils.convertTimestampToLocalDateTime(candidate.getCheckInTime()));
        candidateDto.setIsSelected(candidate.getIsSelected());
        candidateDto.setInterviewCompleted(candidate.getInterviewCompleted());
        return candidateDto;
    }

    public Candidate toEntity(CandidateDto candidateDto) {
        Candidate candidate = new Candidate();

        candidate.setName(candidateDto.getName());
        candidate.setEmailId(candidateDto.getEmailId());
        candidate.setContactNumber(candidateDto.getContactNumber());
        candidate.setGithubLink(candidateDto.getGithubLink());
        candidate.setLinkedInLink(candidateDto.getLinkedInLink());
        candidate.setResumeS3Link(candidateDto.getResumeS3Link());

        candidate.setAllocateLevelOne(candidateDto.getIsLevelOneAllocated());
        candidate.setFeedbackLevelOne(candidateDto.getFeedbackLevelOne());
        candidate.setClearedLevelOne(candidateDto.getIsLevelOneCleared());
//        Optional.ofNullable(candidateDto.getPanelistLevelOne())
//                .ifPresent(panelistDto -> candidate.setPanelistLevelOne(panelistMapper.toEntity(panelistDto)));

        candidate.setAllocatedLevelTwo(candidateDto.getIsLevelTwoAllocated());
        candidate.setFeedbackLevelTwo(candidateDto.getFeedbackLevelTwo());
        candidate.setClearedLevelTwo(candidateDto.getIsLevelTwoCleared());
//        Optional.ofNullable(candidateDto.getPanelistLevelTwo())
//                .ifPresent(panelistDto -> candidate.setPanelistLevelTwo(panelistMapper.toEntity(panelistDto)));

        Iterator<String> skills = candidateDto.getPrimarySkills().iterator();
        if (skills.hasNext()) {
            candidate.setPrimarySkillOne(skills.next());
            if (skills.hasNext())
                candidate.setPrimarySkillTwo(skills.next());
            if (skills.hasNext())
                candidate.setPrimarySkillThree(skills.next());
        }

        candidate.setDateOfBlitz(CommonUtils.convertLocalDateToDate(candidateDto.getDateOfBlitz()));
        candidate.setIsCheckedIn(candidateDto.getIsCheckedIn());
        candidate.setCheckInTime(CommonUtils.convertLocalDateTimeToTimestamp(candidateDto.getCheckInTime()));
        candidate.setIsSelected(candidateDto.getIsSelected());
        candidate.setInterviewCompleted(candidateDto.getInterviewCompleted());
        return candidate;
    }
}
