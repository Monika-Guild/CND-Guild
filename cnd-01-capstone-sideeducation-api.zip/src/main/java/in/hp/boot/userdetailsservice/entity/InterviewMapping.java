package in.hp.boot.userdetailsservice.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.sql.Timestamp;

@Data
@NoArgsConstructor
@Entity
@Table(name = "INTERVIEW_MAPPING")
public class InterviewMapping {

    @Id
    @GeneratedValue
    private Integer id;
    @Column(name = "candidate_name")
    private String candidateName;
    @Column(name = "candidate_email_id")
    private String candidateEmailId;
    @Column(name = "panelist_name")
    private String panelistName;
    @Column(name = "panelist_email_id")
    private String panelistEmailId;
    @Column(name = "level")
    private String interviewLevel;
    @Column(name = "technology")
    private String technology;
    @Column(name = "time_slot")
    private Timestamp timeSlot;
    @Column(name = "email_flag")
    private Boolean emailFlag;

    public InterviewMapping(String candidateName, String candidateEmailId,
                            String panelistName, String panelistEmailId,
                            String interviewLevel, String technology,
                            Timestamp timeSlot, Boolean emailFlag) {
        this.candidateName = candidateName;
        this.candidateEmailId = candidateEmailId;
        this.panelistName = panelistName;
        this.panelistEmailId = panelistEmailId;
        this.interviewLevel = interviewLevel;
        this.technology = technology;
        this.timeSlot = timeSlot;
        this.emailFlag = emailFlag;
    }

    public static InterviewMappingBuilder builder() {
        return new InterviewMappingBuilder();
    }

    public static class InterviewMappingBuilder {
        private String candidateName;
        private String candidateEmailId;
        private String panelistName;
        private String panelistEmailId;
        private String interviewLevel;
        private String technology;
        private Timestamp timeSlot;
        private Boolean emailFlag;

        public InterviewMappingBuilder setBasicDetails(Panelist panelist, Candidate candidate) {
            this.candidateName = candidate.getName();
            this.candidateEmailId = candidate.getEmailId();
            this.technology = candidate.getPrimarySkillOne();
            this.panelistName = panelist.getName();
            this.panelistEmailId = panelist.getEmailId();
            return this;
        }

        public InterviewMappingBuilder setInterviewLevel(String level) {
            this.interviewLevel = level;
            return this;
        }

        public InterviewMappingBuilder setTimeSlot(Timestamp timeSlot) {
            this.timeSlot = timeSlot;
            return this;
        }

        public InterviewMappingBuilder setEmailFlag(Boolean emailFlag) {
            this.emailFlag = emailFlag;
            return this;
        }

        public InterviewMapping build() {
            return new InterviewMapping(this.candidateName, this.candidateEmailId,
                    this.panelistName, this.panelistEmailId, this.interviewLevel,
                    this.technology, this.timeSlot, this.emailFlag);
        }
    }
}
