package in.hp.boot.userdetailsservice.dto;

import lombok.Data;

@Data
public class LambdaDto {
    private String email;
    private String type;
    private String message;
}
