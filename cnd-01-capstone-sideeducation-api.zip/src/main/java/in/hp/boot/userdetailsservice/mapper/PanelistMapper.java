package in.hp.boot.userdetailsservice.mapper;

import in.hp.boot.userdetailsservice.dto.CandidateDto;
import in.hp.boot.userdetailsservice.dto.PanelistDto;
import in.hp.boot.userdetailsservice.entity.Candidate;
import in.hp.boot.userdetailsservice.entity.Panelist;
import in.hp.boot.userdetailsservice.utils.AppConstants;
import in.hp.boot.userdetailsservice.utils.CommonUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * TODO: Should be implemented using mapstruct later
 */
@Component
public class PanelistMapper {

    @Autowired
    CandidateMapper candidateMapper;

    public PanelistDto toDto(Panelist panelist) {
        if (panelist == null) return null;

        PanelistDto panelistDto = new PanelistDto();
        panelistDto.setName(panelist.getName());
        panelistDto.setEmailId(panelist.getEmailId());
        panelistDto.setContactNumber(panelist.getContactNumber());
        panelistDto.setIsCheckedIn(panelist.getIsCheckedIn());
        panelistDto.setIsAvailable(panelist.getIsAvailable());
        panelistDto.setCurrentLevel(panelist.getCurrentLevel());
        panelistDto.setIsTalent(panelist.getIsTalent());

        List<CandidateDto> candidatesDto = null;
        if (panelistDto.getCurrentLevel().equals(AppConstants.LEVEL_ONE)) {
            Optional<List<Candidate>> candidatesLevelOne = Optional.ofNullable(panelist.getCandidatesLevelOne());
            if (candidatesLevelOne.isPresent())
                candidatesDto = panelist.getCandidatesLevelOne()
                        .stream().map(candidateMapper::toDto).collect(Collectors.toList());
        } else {
            Optional<List<Candidate>> candidatesLevelTwo = Optional.ofNullable(panelist.getCandidatesLevelTwo());
            if (candidatesLevelTwo.isPresent())
                candidatesDto = panelist.getCandidatesLevelTwo()
                        .stream().map(candidateMapper::toDto).collect(Collectors.toList());
        }
        panelistDto.setCandidates(candidatesDto);

        // mapping date
        panelistDto.setDateOfBlitz(CommonUtils.convertDateToLocalDate(panelist.getDateOfBlitz()));

        // mapping timestamp
        panelistDto.setCheckInTime(CommonUtils.convertTimestampToLocalDateTime(panelist.getCheckInTime()));
        panelistDto.setAvailableStartTime(CommonUtils.convertTimestampToLocalDateTime(panelist.getAvailableStartTime()));
        panelistDto.setAvailableEndTime(CommonUtils.convertTimestampToLocalDateTime(panelist.getAvailableEndTime()));

        List<String> primarySkills = Stream.of(
                panelist.getPrimarySkillOne(),
                panelist.getPrimarySkillTwo(),
                panelist.getPrimarySkillThree())
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        panelistDto.setPrimarySkills(primarySkills);

        return panelistDto;
    }

    public Panelist toEntity(PanelistDto panelistDto) {
        Panelist panelist = new Panelist();
        panelist.setName(panelistDto.getName());
        panelist.setEmailId(panelistDto.getEmailId());
        panelist.setContactNumber(panelistDto.getContactNumber());
        panelist.setIsCheckedIn(panelistDto.getIsCheckedIn());
        panelist.setIsAvailable(panelistDto.getIsAvailable());
        panelist.setCurrentLevel(panelistDto.getCurrentLevel());
        panelist.setIsTalent(panelistDto.getIsTalent());

        Optional<List<CandidateDto>> candidatesDto = Optional.ofNullable(panelistDto.getCandidates());
        if (candidatesDto.isPresent()) {
            List<Candidate> candidates = candidatesDto.get().stream()
                    .map(candidateMapper::toEntity).collect(Collectors.toList());
            if (panelist.getCurrentLevel().equals(AppConstants.LEVEL_ONE)) {
                panelist.setCandidatesLevelOne(candidates);
            } else {
                panelist.setCandidatesLevelTwo(candidates);
            }
        }

        // mapping date
        panelist.setDateOfBlitz(CommonUtils.convertLocalDateToDate(panelistDto.getDateOfBlitz()));

        // mapping timestamp
        panelist.setCheckInTime(CommonUtils.convertLocalDateTimeToTimestamp(panelistDto.getCheckInTime()));
        panelist.setAvailableStartTime(CommonUtils.convertLocalDateTimeToTimestamp(panelistDto.getAvailableStartTime()));
        panelist.setAvailableEndTime(CommonUtils.convertLocalDateTimeToTimestamp(panelistDto.getAvailableEndTime()));

        // mapping first three skills only
        Iterator<String> primarySkillsIterator = panelistDto.getPrimarySkills().iterator();
        if (primarySkillsIterator.hasNext()) {
            panelist.setPrimarySkillOne(primarySkillsIterator.next());
            if (primarySkillsIterator.hasNext()) {
                panelist.setPrimarySkillTwo(primarySkillsIterator.next());
            }
            if (primarySkillsIterator.hasNext()) {
                panelist.setPrimarySkillThree(primarySkillsIterator.next());
            }
        }
        return panelist;
    }
}
