package in.hp.boot.userdetailsservice.controller;

import in.hp.boot.userdetailsservice.dto.CandidateDto;
import in.hp.boot.userdetailsservice.dto.PanelistDto;
import in.hp.boot.userdetailsservice.service.PanelistService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("/panelists")
public class PanelistController {

    @Autowired
    private PanelistService panelistService;

    @GetMapping
    public List<PanelistDto> getAllPanelists() {
        return panelistService.getAllPanelists();
    }

    @GetMapping("/{email}")
    public ResponseEntity<PanelistDto> getPanelistByEmail(@PathVariable String email) {
        PanelistDto panelist = panelistService.getPanelist(email);
        return Objects.nonNull(panelist) ? ResponseEntity.ok(panelist) : ResponseEntity.badRequest().build();
    }

    @PostMapping
    public ResponseEntity<Object> addPanelist(@RequestBody PanelistDto panelistDto) {
        boolean isPersisted = panelistService.addPanelist(panelistDto);
        HttpStatus status = isPersisted ? HttpStatus.OK : HttpStatus.BAD_REQUEST;
        return ResponseEntity.status(status).build();
    }

    @DeleteMapping("/{email}")
    public ResponseEntity<Object> deletePanelist(@PathVariable String email) {
        return panelistService.deletePanelist(email) ? ResponseEntity.ok().build()
                : ResponseEntity.badRequest().build();
    }

    @PostMapping("/checkIn/{email}")
    public ResponseEntity<Object> checkIn(@PathVariable String email) {
        boolean isUpdated = panelistService.checkIn(email);
        HttpStatus status = isUpdated ? HttpStatus.OK : HttpStatus.BAD_REQUEST;
        return ResponseEntity.status(status).build();
    }

    @PostMapping("/clearCandidate/{email}")
    public ResponseEntity<Object> clearCandidate(@PathVariable String email, @RequestBody CandidateDto candidateDto) {
        boolean isCleared = panelistService.clearCandidate(email, candidateDto);
        HttpStatus status = isCleared ? HttpStatus.OK : HttpStatus.INTERNAL_SERVER_ERROR;
        return ResponseEntity.status(status).build();
    }
}
