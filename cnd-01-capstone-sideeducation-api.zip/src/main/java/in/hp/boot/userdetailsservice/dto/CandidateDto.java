package in.hp.boot.userdetailsservice.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
@ApiModel("Candidate")
public class CandidateDto {

    private String name;
    private String emailId;
    private Long contactNumber;

    private String githubLink;
    private String linkedInLink;
    private String resumeS3Link;
    private List<String> primarySkills;

    private LocalDate dateOfBlitz;
    private Boolean isCheckedIn;
    private LocalDateTime checkInTime;

    private Boolean isLevelOneAllocated;
    private PanelistDto panelistLevelOne;
    private String feedbackLevelOne;
    private Boolean isLevelOneCleared;

    private Boolean isLevelTwoAllocated;
    private PanelistDto panelistLevelTwo;
    private String feedbackLevelTwo;
    private Boolean isLevelTwoCleared;
    private Boolean isSelected;
    private Boolean interviewCompleted;
}
