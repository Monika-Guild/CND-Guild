export const environment = {
  production: true,
  apiEndpoint: 'https://x3n12hxnw9.execute-api.us-east-1.amazonaws.com/dev/'
};
