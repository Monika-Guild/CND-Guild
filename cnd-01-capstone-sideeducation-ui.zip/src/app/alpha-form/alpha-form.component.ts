import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-alpha-form',
  templateUrl: './alpha-form.component.html',
  styleUrls: ['./alpha-form.component.css']
})
export class AlphaFormComponent implements OnInit {

  formName = 'alphaForm';
  @Input() formTitle: string;
  // tslint:disable-next-line: no-output-on-prefix
  @Output() onSubmitEvent = new EventEmitter<any>();

  selectedRadioButton: string;
  radioButtons = [];

  formGroup: FormGroup;

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.radioButtons.push({ label: 'Panelist', value: 'panelist' });
    if (this.formTitle && this.formTitle.includes('check')) {
      this.radioButtons.push({ label: 'Candidate', value: 'candidate' });
    } else {
      this.radioButtons.push({ label: 'Talent', value: 'talent' });
    }
    this.createForm();
  }

  createForm() {
    this.formGroup = this.formBuilder.group({
      email: [null],
      name: [null],
      memberSelector: [null],
    });
  }

  onSubmit() {
    console.log('Form is being submitted');
    this.onSubmitEvent.emit(this.formGroup.value);
    // submit the values to backend
    // positive response
    // clear form values
    // redirect to status and fetch values if possible
    // negative response
    // keep form fields
    // show warning, ask to enter proper values
  }
}
