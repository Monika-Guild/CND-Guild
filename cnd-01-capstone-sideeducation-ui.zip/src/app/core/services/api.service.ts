import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, finalize } from 'rxjs/operators';
import { NgxSpinnerService } from 'ngx-spinner';
import { environment } from './../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  jsonOptions = {
    headers: new HttpHeaders({
      // 'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json'
    })
  };

  constructor(
    private httpClient: HttpClient,
    private spinner: NgxSpinnerService
  ) { }

  private formatErrors(error: any) {
    return throwError(error);
  }

  post(path: string, body: any = {}): Observable<any> {
    this.spinner.show();
    return this.httpClient.post(environment.apiEndpoint + path, body, this.jsonOptions)
      .pipe(catchError(this.formatErrors), finalize(() => {
        this.spinner.hide();
      }));
  }

  get(path: string): Observable<any> {
    this.spinner.show();
    return this.httpClient.get(environment.apiEndpoint + path)
      .pipe(catchError(this.formatErrors), finalize(() => {
        this.spinner.hide();
      }));
  }
}
