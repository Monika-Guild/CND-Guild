import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

import { ApiService } from './api.service';
import { Panelist } from './../models/Panelist';
import { Candidate } from './../models/Candidate';

@Injectable({
  providedIn: 'root'
})
export class PanelistService {

  public panelistSubject = new BehaviorSubject<Panelist[]>([]);
  private panelists: Panelist[] = [];

  constructor(private apiService: ApiService) { }

  setPanelists(panelists: Panelist[]) {
    this.panelists = panelists;
    this.panelistSubject.next(panelists);
  }

  getPanelists(path: string): Observable<any> {
    return this.apiService.get(path);
  }

  clearCandidate(email: string, candidate: Candidate): Observable<any> {
    candidate.checkInTime = '';
    const path = 'panelists/clearCandidate/' + email;
    return this.apiService.post(path, candidate);
  }

  removeCandidate(panelistIndex: number, candidateIndex: number): void {
    this.panelists[panelistIndex].candidates.splice(candidateIndex, 1);
    this.panelistSubject.next(this.panelists);
  }
}
