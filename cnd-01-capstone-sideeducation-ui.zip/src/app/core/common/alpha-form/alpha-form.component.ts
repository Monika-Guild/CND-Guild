import { Component, OnInit, Input, Output, EventEmitter, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Subscription } from 'rxjs';
import { EventService } from './../../services/event.service';

@Component({
  selector: 'app-alpha-form',
  templateUrl: './alpha-form.component.html',
  styleUrls: ['./alpha-form.component.css']
})
export class AlphaFormComponent implements OnInit, OnDestroy {

  formName = 'alphaForm';
  @Input() formTitle: string;
  // tslint:disable-next-line: no-output-on-prefix
  @Output() onSubmitEvent = new EventEmitter<any>();

  selectedRadioButton: string;
  radioButtons = [];
  showError = false;
  errorMessage = '';
  eventSubscription: Subscription;

  formGroup: FormGroup;

  constructor(private formBuilder: FormBuilder, private eventService: EventService) { }

  ngOnInit() {
    this.eventSubscription = this.eventService.eventSubject.subscribe(message => {
      if (message === 'resetForm') {
        this.createForm();
      }
    });

    if (this.formTitle && this.formTitle.includes('check')) {
      this.radioButtons.push({ label: 'Panelist / Talent', value: 'panelist' });
      this.radioButtons.push({ label: 'Candidate', value: 'candidate' });
    } else {
      this.radioButtons.push({ label: 'Panelist', value: 'panelist' });
      this.radioButtons.push({ label: 'Talent', value: 'talent' });
    }
    this.createForm();
  }

  createForm() {
    this.formGroup = this.formBuilder.group({
      email: [null],
      name: [null],
      memberSelector: [null],
    });
  }

  onSubmit() {
    console.log('Form is being submitted');
    this.onSubmitEvent.emit(this.formGroup.value);
  }

  ngOnDestroy(): void {
    this.eventSubscription.unsubscribe();
  }
}
