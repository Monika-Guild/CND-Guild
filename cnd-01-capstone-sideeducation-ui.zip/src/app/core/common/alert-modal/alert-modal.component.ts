import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { ThemePalette } from '@angular/material/core';
import { AlertMessage } from './../../models/AlertMessage';

@Component({
  selector: 'app-alert-modal',
  templateUrl: './alert-modal.component.html',
  styleUrls: ['./alert-modal.component.css']
})
export class AlertModalComponent implements OnInit {

  @Input() showSuccessMessage: boolean;
  @Output() closePopupEvent = new EventEmitter<boolean>();

  alertMessage = new AlertMessage();
  buttonThemePalette: ThemePalette;
  resetForm: boolean;

  constructor() { }

  ngOnInit(): void {
    if (this.showSuccessMessage) {
      this.alertMessage.title = 'Successfully Submitted.';
      this.alertMessage.subtitle = 'Press Okay to close the popup.';
      this.buttonThemePalette = 'primary';
      this.buttonThemePalette = 'primary';
      this.resetForm = true;
    } else {
      this.alertMessage.title = 'Invalid Data..!';
      this.alertMessage.subtitle = 'Please enter correct email id and name. Press Okay to close the popup.';
      this.buttonThemePalette = 'warn';
      this.resetForm = false;
    }
  }

  closePopup(): void {
    this.closePopupEvent.emit(this.resetForm);
  }

}
