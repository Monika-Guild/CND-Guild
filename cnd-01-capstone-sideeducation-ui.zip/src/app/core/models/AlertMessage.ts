export class AlertMessage {
  title: string;
  subtitle: string;
}
