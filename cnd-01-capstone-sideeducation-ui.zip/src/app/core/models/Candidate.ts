export class Candidate {
  checkInTime: string;
  contactNumber: number;
  dateOfBlitz: string;
  emailId: string;
  feedbackLevelOne: string;
  feedbackLevelTwo: string;
  githubLink: string;
  interviewCompleted: boolean;
  isCheckedIn: boolean;
  isLevelOneAllocated: boolean;
  isLevelOneCleared: boolean;
  isLevelTwoAllocated: boolean;
  isLevelTwoCleared: boolean;
  isSelected: boolean;
  linkedInLink: string;
  name: string;
  primarySkills: Array<string>;
  resumeS3Link: string;
}
