import { Candidate } from './Candidate';
export class Panelist {
  availableEndTime: string;
  availableStartTime: string;
  candidates: Array<Candidate>;
  checkInTime: string;
  contactNumber: number;
  currentLevel: string;
  isTalent: boolean;
  dateOfBlitz: string;
  emailId: string;
  isAvailable: boolean;
  isCheckedIn: boolean;
  name: string;
  primarySkills: Array<string>;
}
