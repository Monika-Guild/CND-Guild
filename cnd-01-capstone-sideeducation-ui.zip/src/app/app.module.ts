import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

import { MaterialModule } from './shared/material.module';
import { NgxSmartModalModule } from 'ngx-smart-modal';
import { NgxSpinnerModule } from 'ngx-spinner';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { LayoutComponent } from './layout/layout.component';
import { HeaderComponent } from './layout/header/header.component';
import { FooterComponent } from './layout/footer/footer.component';

import { AlphaFormComponent } from './core/common/alpha-form/alpha-form.component';
import { AlertModalComponent } from './core/common/alert-modal/alert-modal.component';

import { HomeComponent } from './screens/home/home.component';
import { CheckInComponent } from './screens/check-in/check-in.component';
import { StatusComponent } from './screens/status/status.component';
import { PanelistComponent } from './screens/status/panelist/panelist.component';
import { FeedbackFormComponent } from './screens/status/feedback-form/feedback-form.component';

@NgModule({
  declarations: [
    AppComponent,
    LayoutComponent,
    HomeComponent,
    HeaderComponent,
    FooterComponent,
    StatusComponent,
    CheckInComponent,
    AlphaFormComponent,
    FeedbackFormComponent,
    PanelistComponent,
    AlertModalComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpClientModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    NgxSmartModalModule.forRoot(),
    NgxSpinnerModule,
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule { }
