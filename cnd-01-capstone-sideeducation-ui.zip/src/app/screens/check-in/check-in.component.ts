import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';

import { NgxSmartModalService } from 'ngx-smart-modal';

import { ApiService } from './../../core/services/api.service';
import { EventService } from '../../core/services/event.service';

@Component({
  selector: 'app-check-in',
  templateUrl: './check-in.component.html',
  styleUrls: ['./check-in.component.css']
})
export class CheckInComponent implements OnInit {

  formTitle = 'Who is checking in?';
  showAlert = false;
  showSuccessMessage = true;

  constructor(
    private apiService: ApiService,
    private eventService: EventService,
    private ngxSmartModelService: NgxSmartModalService) { }

  ngOnInit(): void {
  }

  onSubmit(event: any) {
    console.log(event);
    if (event && event.email && event.memberSelector) {
      let path = '';
      if (event && event.memberSelector.includes('candidate')) {
        path = 'candidates/checkIn/' + event.email;
      } else {
        path = 'panelists/checkIn/' + event.email;
      }

      this.apiService.post(path).subscribe(
        (value) => {
          console.log(value);
          this.openModal(true);
        },
        (error) => {
          if (error instanceof HttpErrorResponse) {
            console.error(error.status);
          }
          this.openModal(false);
        }
      );
    }
  }

  openModal(showSuccess: boolean): void {
    this.showAlert = true;
    this.showSuccessMessage = showSuccess;
    this.ngxSmartModelService.open('alertPopup');
  }

  closeModal(event: boolean): void {
    this.ngxSmartModelService.close('alertPopup');
    if (event) {
      this.eventService.eventSubject.next('resetForm');
    }
  }

}
