import { Component, OnInit, Input, Output, EventEmitter, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { Subscription } from 'rxjs';

import { PanelistService } from './../../../core/services/panelist.service';
import { Candidate } from './../../../core/models/Candidate';
import { Panelist } from './../../../core/models/Panelist';

@Component({
  selector: 'app-feedback-form',
  templateUrl: './feedback-form.component.html',
  styleUrls: ['./feedback-form.component.css']
})
export class FeedbackFormComponent implements OnInit, OnDestroy {

  @Input() panelistIndex: number;
  @Input() candidateIndex: number;
  @Output() closeFormEvent = new EventEmitter<any>(); // Change the interface to Candidate when you work on scripts.

  panelist: Panelist;
  candidate: Candidate;
  panelistSubscription: Subscription;

  formName = 'feedbackForm';
  formGroup: FormGroup;
  radioButtons = [
    { label: 'Cleared', value: true },
    { label: 'Not Cleared', value: false }
  ];

  constructor(
    private formBuilder: FormBuilder,
    private panelistService: PanelistService
  ) { }

  ngOnInit(): void {
    this.panelistSubscription = this.panelistService.panelistSubject.subscribe(p => {
      this.panelist = p[this.panelistIndex];
      this.candidate = this.panelist.candidates[this.candidateIndex];
    });
    // this.candidate = new Candidate();
    // this.candidate.name = 'Hariprasath';
    // this.candidate.emailId = 'haripr@deloitte.com';
    // this.candidate.primarySkills = [
    //   'Java', 'Angular', 'AWS'
    // ];
    // this.candidate.feedbackLevelOne = 'He\'s cleared.';
    // this.candidate.isLevelOneCleared = true;

    // this.panelist = new Panelist();
    // this.panelist.currentLevel = 'TWO';

    this.createForm();
  }

  ngOnDestroy(): void {
    this.panelistSubscription.unsubscribe();
  }

  createForm(): void {
    this.formGroup = this.formBuilder.group({
      feedbackLevelOne: ['', Validators.required],
      feedbackLevelTwo: [''],
      memberSelector: [null],
    });

    if (this.panelist.currentLevel === 'TWO') {
      this.formGroup.controls.feedbackLevelOne.setValue(this.candidate.feedbackLevelOne);
      this.formGroup.controls.feedbackLevelOne.disable();
      this.formGroup.controls.feedbackLevelTwo.setValidators(Validators.required);
    }
  }

  submitForm(): void {
    const level = this.panelist.currentLevel;
    const candidate = {...this.candidate};
    switch (level) {
      case 'ONE':
        candidate.feedbackLevelOne = this.formGroup.controls.feedbackLevelOne.value;
        candidate.isLevelOneCleared = this.formGroup.controls.memberSelector.value;
        break;
      default:
        candidate.feedbackLevelTwo = this.formGroup.controls.feedbackLevelTwo.value;
        candidate.isLevelTwoCleared = this.formGroup.controls.memberSelector.value;
        break;
    }
    console.log(candidate);
    // this.closeForm();

    this.panelistService.clearCandidate(this.panelist.emailId, candidate).subscribe(
      (value) => {
        this.panelistService.removeCandidate(this.panelistIndex, this.candidateIndex);
        this.closeForm();
      },
      (error) => {
        let msg = 'Invalid Request';
        if (error instanceof HttpErrorResponse) {
          msg = msg + error.status;
        }
        console.error(msg);
      }
    );
  }

  closeForm(): void {
    this.closeFormEvent.emit();
  }

}
