import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { NgxSmartModalService } from 'ngx-smart-modal';

import { PanelistService } from './../../core/services/panelist.service';
import { Panelist } from './../../core/models/Panelist';

@Component({
  selector: 'app-status',
  templateUrl: './status.component.html',
  styleUrls: ['./status.component.css']
})
export class StatusComponent implements OnInit, OnDestroy {

  statusSubmitted = false;
  enableFeedback = true;
  showAlert = false;

  constructor(
    private panelistService: PanelistService,
    private ngxSmartModelService: NgxSmartModalService) { }

  ngOnInit(): void { }

  ngOnDestroy(): void { }

  onSubmit(event: any) {
    console.log(event);
    let path = 'panelists';
    if (event.memberSelector.includes('panelist')) {
      path = path + '/' + event.email;
      this.enableFeedback = true;
    } else {
      this.enableFeedback = false;
    }

    this.panelistService.getPanelists(path).subscribe(
      (value) => {
        console.log(value);
        let panelists: Panelist[] = Array.isArray(value) ? value : Array.of(value);
        panelists = panelists.filter(p => p.isAvailable);
        if (panelists.length < 1 || !this.isValidTalent(this.enableFeedback, panelists, event.email)) {
          this.statusSubmitted = false;
          this.openModal();
        } else {
          this.panelistService.setPanelists(panelists);
          this.statusSubmitted = true;
        }
      },
      (error) => {
        let msg = 'Invalid Request';
        if (error instanceof HttpErrorResponse) {
          msg = msg + error.status;
        }
        console.error(msg);
        this.statusSubmitted = false;
        this.openModal();
      }
    );
  }

  isValidTalent(isPanelist: boolean, panelists: Panelist[], email: string): boolean {
    const filteredPanelists = panelists.filter(p => p.emailId === email);
    const isTalent = filteredPanelists[0] ? filteredPanelists[0].isTalent : false;

    if ((isPanelist && isTalent) || (!isPanelist && !isTalent)) {
      return false;
    } else {
      return true;
    }
  }

  reset(status: boolean) {
    this.statusSubmitted = false;
  }

  openModal(): void {
    this.showAlert = true;
    this.ngxSmartModelService.open('statusAlertPopup');
  }

  closeModal(): void {
    this.ngxSmartModelService.close('statusAlertPopup');
  }

}
