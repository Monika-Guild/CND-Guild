import { Component, OnInit, Output, EventEmitter, Input, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { NgxSmartModalService } from 'ngx-smart-modal';

import { PanelistService } from './../../../core/services/panelist.service';
import { Candidate } from './../../../core/models/Candidate';
import { Panelist } from './../../../core/models/Panelist';

@Component({
  selector: 'app-panelist',
  templateUrl: './panelist.component.html',
  styleUrls: ['./panelist.component.css']
})
export class PanelistComponent implements OnInit, OnDestroy {

  @Input() enableFeedback: boolean;
  @Output() resetDetails = new EventEmitter();

  panelists: Panelist[];
  currentCandidate: Candidate;
  currentPanelist: Panelist;
  currentCandidateIndex = -1;
  currentPanelistIndex = -1;

  // statistics data
  totalPanelists = 0;
  totalCandidates = 0;
  lvl1Candidates = 0;
  lvl2Candidates = 0;

  showForm = false;
  panelistSubscription: Subscription;

  constructor(
    private panelistService: PanelistService,
    private ngxSmartModelService: NgxSmartModalService
  ) { }

  ngOnInit(): void {
    this.panelistSubscription = this.panelistService.panelistSubject.subscribe((value: Panelist[]) => {
      this.panelists = value.filter(p => !p.isTalent);
      this.getTotalScreenedCandidates();
      this.filterAvailablePanelists();
      this.filterCandidatesByLevel();
    });
  }

  getTotalScreenedCandidates(): void {
    const candidatesCleared = new Set<string>();
    this.panelists.forEach(p => p.candidates.forEach(c => {
      if (c.interviewCompleted) {
        candidatesCleared.add(c.emailId);
      }
    }));
    this.totalCandidates = candidatesCleared.size;
  }

  filterAvailablePanelists(): void {
    this.panelists = this.panelists.filter(p => p.isAvailable);
    this.totalPanelists = this.panelists.length;
  }

  filterCandidatesByLevel(): void {
    const filteredPanelists = this.panelists.map(panelist => {
      const level = panelist.currentLevel;
      switch (level) {
        case 'ONE':
          const filteredCandidatesLevel1 = panelist.candidates
            .filter(candidate => !candidate.isLevelOneCleared && !candidate.interviewCompleted);
          panelist.candidates = filteredCandidatesLevel1;
          this.lvl1Candidates += filteredCandidatesLevel1.length;
          break;
        case 'TWO':
          const filteredCandidatesLevel2 = panelist.candidates
            .filter(candidate => !candidate.isLevelTwoCleared && !candidate.interviewCompleted);
          panelist.candidates = filteredCandidatesLevel2;
          this.lvl2Candidates += filteredCandidatesLevel2.length;
          break;
      }
      return panelist;
    });
    this.panelists = filteredPanelists;
  }

  editCandidate(i: number, j: number): void {
    this.currentPanelistIndex = i;
    this.currentCandidateIndex = j;
    this.showForm = true;
    this.ngxSmartModelService.open('feedbackForm');
  }

  closePopup(): void {
    this.ngxSmartModelService.close('feedbackForm');
  }

  resetForm(): void {
    this.resetDetails.emit(true);
  }

  ngOnDestroy(): void {
    this.panelistSubscription.unsubscribe();
  }

}
