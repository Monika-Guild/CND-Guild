import { Panelist } from './../model/Panelist';
import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';

import { ApiService } from './../services/api.service';

@Component({
  selector: 'app-status',
  templateUrl: './status.component.html',
  styleUrls: ['./status.component.css']
})
export class StatusComponent implements OnInit {
  public statusSubmitted = false;

  panelists: Panelist[] = [];

  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
  }


  onSubmit(event: any) {
    console.log(event);
    if (event && event.email && event.memberSelector) {
      let path = '';
      if (event && event.memberSelector.includes('panelist')) {
        path = 'panelists/' + event.email;
      } else {
        path = 'panelists';
      }
      this.apiService.get(path).subscribe(
        (value) => {
          console.log(value);
          if (Array.isArray(value)) {
            this.panelists = value;
          } else {
            this.panelists.push(value);
          }
        },
        (error) => {
          let msg = 'Invalid Request';
          if (error instanceof HttpErrorResponse) {
            msg = msg + error.status;
          }
          alert(msg);
        }
      );
    }
    this.statusSubmitted = true;
    console.log(this.panelists);
  }

  reset(status: boolean) {
    this.panelists = [];
    this.statusSubmitted = !status;
  }

}
