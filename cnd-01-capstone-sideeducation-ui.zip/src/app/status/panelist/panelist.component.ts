import { Candidate } from './../../model/Candidate';
import { Panelist } from './../../model/Panelist';
import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { NgxSmartModalService } from 'ngx-smart-modal';

@Component({
  selector: 'app-panelist',
  templateUrl: './panelist.component.html',
  styleUrls: ['./panelist.component.css']
})
export class PanelistComponent implements OnInit {

  @Input() panelists: Panelist[];
  @Output() resetDetails = new EventEmitter();

  currentCandidate: Candidate;
  currentCandidateIndex = -1;
  currentPanelistIndex = -1;

  showForm = false;

  constructor(private ngxSmartModelService: NgxSmartModalService) { }

  ngOnInit(): void { }

  editCandidate(i: number, j: number): void {
    this.currentPanelistIndex = i;
    this.currentCandidateIndex = j;
    this.currentCandidate = this.panelists[i].candidates[j];
    console.log('Chosen candidate: ' + this.currentCandidate.name);
    this.showForm = true;
    this.ngxSmartModelService.open('feedbackForm');
  }

  onfeedbackSaved(candidate: Candidate): void {
    this.ngxSmartModelService.close('feedbackForm');
    this.panelists[this.currentPanelistIndex].candidates[this.currentCandidateIndex] = candidate;
    // api call to update candidate
  }

  resetForm(): void {
    this.resetDetails.emit(true);
  }
}
