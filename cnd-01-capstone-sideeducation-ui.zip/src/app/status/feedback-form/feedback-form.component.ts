import { Candidate } from './../../model/Candidate';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-feedback-form',
  templateUrl: './feedback-form.component.html',
  styleUrls: ['./feedback-form.component.css']
})
export class FeedbackFormComponent implements OnInit {

  @Input() candidate: Candidate;
  @Output() feedbackSaved = new EventEmitter<any>(); // Change the interface to Candidate when you work on scripts.

  constructor() { }

  ngOnInit(): void {
  }

  onSubmit(e){
    alert("Feedback submitted!");
    this.feedbackSaved.emit(e);
  }

}
