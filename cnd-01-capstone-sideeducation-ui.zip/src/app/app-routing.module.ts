import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './screens/home/home.component';
import { StatusComponent } from './screens/status/status.component';
import { CheckInComponent } from './screens/check-in/check-in.component';
import { PanelistComponent } from './screens/status/panelist/panelist.component';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'status', component: StatusComponent, children: [] },
  { path: 'panel-details', component: PanelistComponent},
  { path: 'checkin', component: CheckInComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
