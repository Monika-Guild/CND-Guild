import { Component, OnInit } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';

import { ApiService } from './../services/api.service';

@Component({
  selector: 'app-check-in',
  templateUrl: './check-in.component.html',
  styleUrls: ['./check-in.component.css']
})
export class CheckInComponent implements OnInit {

  formTitle = 'Who is checking in?';

  constructor(private apiService: ApiService) { }

  ngOnInit(): void {
  }

  onSubmit(event: any) {
    console.log(event);
    if (event && event.email && event.memberSelector) {
      let path = '';
      if (event && event.memberSelector.includes('candidate')) {
        path = 'candidates/checkIn/' + event.email;
      } else {
        path = 'panelists/checkIn/' + event.email;
      }
      this.apiService.post(path).subscribe(
        (value) => {
          console.log(value);
          alert('Check-in form submitted');
        },
        (error) => {
          let msg = 'Invalid Request';
          if (error instanceof HttpErrorResponse) {
            msg = msg + error.status;
          }
          alert(msg);
        }
      );
    }
  }

}
