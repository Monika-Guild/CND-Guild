import boto3
import csv
import io
import time

# Create an S3 client
s3_client = boto3.client('s3')
bucket_name = 'sa-data-from-dynamodb'

def lambda_handler(event, context):
    print(event)
    if event['Records'][0]['eventName'] == "INSERT" or event['Records'][0]['eventName'] == "MODIFY":
        csvio = io.StringIO()
        writer = csv.writer(csvio)
        writer.writerow(['userId', 'date', 'contactId', 'city', 'phone', 'alertStatus'])
        
        newImage = event['Records'][0]['dynamodb']['NewImage']
        userId = newImage['userId']['S']
        date = newImage['date']['S']
        contactId = newImage['contactList']['L'][0]['M']['contactId']['S']
        city = newImage['contactList']['L'][0]['M']['city']['S']
        phone = newImage['contactList']['L'][0]['M']['phone']['S']
        alertStatus = newImage['contactList']['L'][0]['M']['alertStatus']['N']
        writer.writerow([userId, date, contactId, city, phone, alertStatus])
        
        timestr = time.strftime("%Y%m%d-%H%M%S")
        s3_client.put_object(Body=csvio.getvalue(), ContentType='text/csv', Bucket=bucket_name, Key= timestr + '-' + userId + '.csv') 
        csvio.close()
