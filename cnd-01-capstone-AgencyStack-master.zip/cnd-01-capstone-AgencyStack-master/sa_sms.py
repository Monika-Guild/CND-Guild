import json
import boto3
from datetime import datetime, timedelta
from boto3.dynamodb.conditions import Key

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('contactTracing')
impactedDate = (datetime.today() - timedelta(days=14)).date()

def query_contactListItems(userId, impactedDate):
    response = table.query(
        KeyConditionExpression=Key('userId').eq(userId) & Key('date').gte(str(impactedDate))
    )
    return response['Items']

sns = boto3.client('sns')

contactList = set()

def lambda_handler(event, context):
    contactListItems = query_contactListItems("000000001", impactedDate)
    # print(contactListItems[0]['userFirstName'] + contactListItems[0]['userLastName'])
    # print(len(contactListItems))
    for contacts in contactListItems:
        for contact in contacts['contactList']:
            contactList.add(contact['phone'])
            # print(contact['phone'])
        # print(contact['contactList'][0]['city'])
    print(contactList)
    for contact in contactList:
        sns.publish(PhoneNumber=contact, Message="Unfortunately, I just tested positive for Covid-19. Since, we met in the last 2 weeks, please visit a doctor and get tested at the earliest.\n-Amit")
    return {
        'statusCode': 200,
        'body': json.dumps('Your friends are notified with whom you came in contact in last 2 weeks since ' + event['date'])
    }
