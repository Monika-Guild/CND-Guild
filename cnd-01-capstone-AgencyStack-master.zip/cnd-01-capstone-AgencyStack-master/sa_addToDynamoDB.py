# import the json utility package since we will be working with a JSON object
import json
# import the AWS SDK (for Python the package name is boto3)
import boto3
from botocore.exceptions import ClientError
from boto3.dynamodb.conditions import Key

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('contactTracing')

def getItems(userId, date):
    response = table.query(
        KeyConditionExpression=Key('userId').eq(userId) & Key('date').eq(str(date))
    )
    return response['Items']
    
def lambda_handler(event, context):
    items = getItems("000000001", event['date'])
    print(items)
    if not items:
        print("New item:")
        response = table.put_item(
            Item={
                "userId": "000000001",
                "userFirstName": "Amit",
                "userLastName": "Sharma",
                'date': event['date'],
                'contactList': [
                    {
                        "alertStatus": 0,
                        "city": event['city'],
                        "phone": event['phone'],
                        "contactId": event['contactId']
                    }
                ]
                })
    else:
        print("Item updated:")
        newContact = {
                        "alertStatus": 0,
                        "city": event['city'],
                        "phone": event['phone'],
                        "contactId": event['contactId']
                    }
        response = table.update_item(
            Key={
                "userId": "000000001",
                'date': event['date'],
            },
            UpdateExpression="SET contactList = list_append(contactList, :newContact)",
            ExpressionAttributeValues={
                ':newContact': [newContact],
            },
            ReturnValues="UPDATED_NEW")

# return a properly formatted JSON object
    return {
        'statusCode': 200,
        'body': json.dumps('Data saved successfully for ' + event['contactId'])
    }
